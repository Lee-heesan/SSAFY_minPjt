// TODO: 개별적으로 발급받은 키를 등록하세요.
const key_vworld = "EA41EA81-C671-3B8C-9356-B33AD1D3931A";
const key_sgis_service_id = "1703282b0112466a89ea"; // 서비스 id
const key_sgis_security = "ed90b9b74caf42d7a907" ;// 보안 key
const key_data = "xIoM22nqzFZqpJACGd2PQ8f%2BNSaB3N4kasWkcFgZP73dC3wm7QGbW3beo2rielYeWNnKACM2Tv5iDfYUX51ocQ%3D%3D"; // data.go.kr 인증키

// END

